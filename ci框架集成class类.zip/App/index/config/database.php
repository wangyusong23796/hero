<?php
defined('BASEPATH') OR exit('No direct script access allowed');

return require '../config/database.php';