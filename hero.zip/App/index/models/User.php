<?php

use Illuminate\Database\Eloquent\Model;

/**
 *
 * Article Model
 *
 */

class User extends Model
{
	public $timestamps = false;

}

