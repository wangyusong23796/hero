<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Article Model
 *
*/

class WebArticles extends Illuminate\Database\Eloquent\Model

{

	public $timestamps = false;

}