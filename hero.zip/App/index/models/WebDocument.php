<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Article Model
 *
*/

class WebDocument extends Illuminate\Database\Eloquent\Model

{

	public $timestamps = false;

}