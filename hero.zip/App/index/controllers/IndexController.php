<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'BaseController.php';


class IndexController extends BaseController{
	
	
	
	public function index()
	{
		
	}
	
	
	
}