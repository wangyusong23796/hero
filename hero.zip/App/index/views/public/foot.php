<!--buttom-->
<div class="buttom_top">
	<div class="buttom_box">
        <dl class="buttom_a">
            <dt>热门资讯</dt>
            <a href="#"><dd>使用3dsmax脚本制作酷炫物体分解动画</dd></a>
            <a href="#"><dd>hea render物理渲染器基础教学_01</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>Unity3d游戏特效实战教程</dd></a>
        </dl>
        <dl class="buttom_a">
            <dt>合作伙伴</dt>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
        </dl>
        <dl class="buttom_a">
            <dt>友情链接</dt>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
        </dl>
        <dl class="buttom_a">
            <dt>常见问题</dt>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
            <a href="#"><dd>色彩原理</dd></a>
        </dl>
    </div>
</div>

<div class="buttom_but">
    <dl class="buttom2_box">
        <dd>POWERED BY <?php echo $webconfig['banquan']?>.</dd>
        <dd><?php echo $webconfig['banquan']?> <?php echo $webconfig['beian']?></dd>
        <dt>
            <a href="">播放器下载</a><span>|</span>
            <a href="">联系我们</a><span>|</span>
            <a href="">加入我们</a><span>|</span>
            <a href="">发布协议</a><span>|</span>
            <a href="">服务条款</a><span>|</span>
            <a href="">版权声明</a><span>|</span>
            <a href="">投票调查</a>
        </dt>
        <a href="#top"><p class="go_top"></p></a>
    </dl>
</div>
</body>
</html>
