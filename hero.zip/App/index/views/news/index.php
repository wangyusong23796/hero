<link href="/index/style/shipin.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="/index/jQuery/shipin.js"></script>


<!--页面顺序-->
<ul class="shunxu">

</ul>


<!--center-->
<div class="center">
    <p class="center_top"><span>视频教程</span></p>
    <div class="center_left">
        <div class="left_a">
            <div class="left_a1">
                <p class="left_a1a">Maya 2016正式版极速上手测评</p>
                <ul class="left_a1b">
                    <li class="left_a1b1"><span>Posted</span>四 01 2015</li>
                    <li class="left_a1b2"><span>by</span>zivix</li>
                    <li class="left_a1b2"><span>在</span>3D, 动画, 建模, 材质, 流程, 视频教学</li>
                    <li class="left_a1b2"><span>with</span>0 评论</li>
                </ul>
            </div>
            <div class="left_a2">
                <img src="images/left_a2.png" alt="Maya 2016正式版极速上手测评" title="Maya 2016正式版极速上手测评" />
            </div>
        </div>
         <!--页码-->
         <div class="left_b">
            <p class="left_b1">第<span>1</span>页，共<a>87</a>页</p>
            <ul class="left_b2">
                <li class="left_b2a">首页</li>
                <li class="left_b2a">上一页</li>
                <li class="left_b2b">1</li>
                <li class="left_b2bon">2</li>
                <li class="left_b2b">3</li>
                <li class="left_b2b">4</li>
                <li class="left_b2b">5</li>
                <li class="left_b2b">87</li>
                <li class="left_b2a">下一页</li>
                <li class="left_b2a">尾页</li>
            </ul>
         </div>
    </div>
    <div class="center_right">
        <div class="right_a">
            <p class="right_top">即时搜索</p>
            <div class="right_a1">
                <input class="right_a1a" name="" type="text" value="赶紧搜索" />
                <input class="right_a1b" name="" type="button" value="" />
            </div>
        </div>
        <div class="right_b">
            <p class="right_top">分类目录</p>
            <p class="right_b1">视频教学520个</p>
            <ul class="right_b2">
                <li class="right_b2li right_b2lion">视频教学520个</li>
                <li class="right_b2li">视频教学1</li>
                <li class="right_b2li">视频教学2</li>
                <li class="right_b2li">视频教学3</li>
                <li class="right_b2li">视频教学4</li>
                <li class="right_b2li">视频教学5</li>
            </ul>
        </div>
        <div class="right_c">
            <p class="right_top">标签</p>
            <ul class="right_c1">
                <li>*CWWS</li>
                <li>*KANYAYAN</li>
                <li>*JUNE</li>
                <li>*NEROBLACK</li>
                <li>*PURPLESUN</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*CWW</li>
                <li>*KANYAYAN</li>
                <li>*JUNE</li>
                <li>*JUNE</li>
                <li>*NEROBLACK</li>
                <li>*PURPLESUN</li>
                <li>*CWWS</li>
                <li>*KANYAYAN</li>
                <li>*JUNE</li>
                <li>*NEROBLACK</li>
                <li>*PURPLESUN</li>
                <li>*CWWS</li>
                <li>*KANYAYAN</li>
                <li>*JUNE</li>
                <li>*NEROBLACK</li>
                <li>*PURPLESUN</li>
            </ul>
        </div>
    </div>
</div>
