

<style>
.display{
	width:1100px; 
	height:750px;
	margin:0 auto;
	margin-top: 120px;
}

.h1bt{
	width:110px;
	height:50px;
	line-height: 50px;
}
.textarticle{
	width:1100px;
	height:550px;
	border:2px solid #91908e;
}
</style>

<div class="display">

        <div class="one_a2"><?php echo $name?></div>
        <div class="textarticle">
           
			<?php echo $article->text;?>

        </div>

</div>
