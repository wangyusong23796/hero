<!--banner-->
<link href="/index/style/index.css" rel="stylesheet" type="text/css" />
<div class="banner_bg"></div>
<div class="banner">
	<div class="banner_tv">
        <ul class="banner_img">
            <li class="banner_img1"><img src="/index/images/banner_img1_1.png" /></li>
            <li class="banner_img1"><img src="/index/images/banner_img1_2.png" /></li>
        </ul>
    </div>
    <ul class="banner_but">
    	<li class="banner_but1"></li>
        <li class="banner_but2"></li>
    </ul>
</div>

<!--center-->
<div class="center">
	<!--one-->
	<div class="one">
    	<div class="one_a">
        	<P class="one_a1"><span>图文教程</span></P>
            <P class="one_a2">制作CG角色”女猎人“的贴图会技巧教程</P>
            <ul class="one_a3">
            	<li class="one_a3a"><span>Posted</span>&nbsp;九&nbsp;21&nbsp;2014 </li>
                <li class="one_a3a"><span>by</span>&nbsp;Steve&nbsp;Jobs</li>
                <li class="one_a3a"><span>在</span>&nbsp;3D,&nbsp;3ds&nbsp;Max,&nbsp;Zbrush,&nbsp;图文教学,&nbsp;流程</li>
                <li class="one_a3a"><span>with</span>&nbsp;1&nbsp;评论</li>
            </ul>
        </div>
        <a href="#"><div class="one_b"><img src="/index/images/one_b1.png" alt="图片" title="图片" /></div></a>
        <div class="one_c">
        	<div class="one_c1">
            	<a href="#"><ul class="one_c1a">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1alion">zbrush结合photoshop创作卡通插视频教学创作卡通插视频教学创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
            <div class="one_c1">
            	<a href="#"><ul class="one_c1a one_c1c">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
            <div class="one_c1">
            	<a href="#"><ul class="one_c1a">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
        </div>
        <div class="one_d">
        	<input name="" type="button" value="MORE" />
        </div>
    </div>
	
    <!--one-->
	<div class="one" style="margin-top:50px;">
    	<div class="one_a">
        	<P class="one_a1"><span>视频教程 </span></P>
            <P class="one_a2">制作CG角色”女猎人“的贴图会技巧教程</P>
            <ul class="one_a3">
            	<li class="one_a3a"><span>Posted</span>&nbsp;九&nbsp;21&nbsp;2014 </li>
                <li class="one_a3a"><span>by</span>&nbsp;Steve&nbsp;Jobs</li>
                <li class="one_a3a"><span>在</span>&nbsp;3D,&nbsp;3ds&nbsp;Max,&nbsp;Zbrush,&nbsp;图文教学,&nbsp;流程</li>
                <li class="one_a3a"><span>with</span>&nbsp;1&nbsp;评论</li>
            </ul>
        </div>
        <a href="#"><div class="one_b"><img src="/index/images/one_b1.png" alt="图片" title="图片" /></div></a>
        <div class="one_c">
        	<div class="one_c1">
            	<a href="#"><ul class="one_c1a">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
            <div class="one_c1">
            	<a href="#"><ul class="one_c1a one_c1c">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
            <div class="one_c1">
            	<a href="#"><ul class="one_c1a">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
        </div>
        <div class="one_d">
        	<input style="margin-top:60px;" name="" type="button" value="MORE" />
        </div>
    </div>

	<!--one-->
	<div class="one" style="margin-top:65px;">
    	<div class="one_a">
        	<P class="one_a1"><span>最新资讯</span></P>
            <P class="one_a2"></P>
            <ul class="one_a3">
            	<li class="one_a3a"><span>Posted</span>&nbsp;九&nbsp;21&nbsp;2014 </li>
                <li class="one_a3a"><span>by</span>&nbsp;Steve&nbsp;Jobs</li>
                <li class="one_a3a"><span>在</span>&nbsp;3D,&nbsp;3ds&nbsp;Max,&nbsp;Zbrush,&nbsp;图文教学,&nbsp;流程</li>
                <li class="one_a3a"><span>with</span>&nbsp;1&nbsp;评论</li>
            </ul>
        </div>
        <a href="#"><div class="one_b"><img src="/index/images/one_b1.png" alt="图片" title="图片" /></div></a>
        <div class="one_c">

        	<div class="one_c1">
            	<a href="#"><ul class="one_c1a">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
            <div class="one_c1">
            	<a href="#"><ul class="one_c1a one_c1c">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
            </div>
            <div class="one_c1">
            	<a href="#"><ul class="one_c1a">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学</li>
                </ul></a>
                <a href="#"><ul class="one_c1a one_c1b">
                	<img src="/index/images/one_c1a.png" alt="图片" title="图片" />
                    <li class="one_c1ali">zbrush结合photoshop创作卡通插视频教学创作卡通插视频教学创作卡通插视频教学创作卡通插视频教学</li>
                </ul></a>
            </div>
        </div>
        <div class="one_d">
        	<input style="margin-top:60px;" name="" type="button" value="MORE" />
        </div>
    </div>
    
</div>