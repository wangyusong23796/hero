<link href="/index/style/Waterfall.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="/index/jQuery/Waterfall.js"></script>
<!--页面顺序-->
<ul class="shunxu">
    <li class="shunxu1">首页</li>
    <li class="shunxu2">></li>
    <li class="shunxu1">图文资讯</li>

</ul>

<div class="Waterfall">
    <div class="Waterfall_top">
        <p class="Waterfall_1"><span>CG瀑布流</span></p>
        <p class="Waterfall_2">以瀑布流的方式呈现全站内容，更加方便阅读。</p>
    </div>
    <div class="Waterfall_but">
        <ul class="Waterfall_3">
            <li class="Waterfall_3aon">All</li>
            <li class="Waterfall_3a">作品欣赏</li>
            <li class="Waterfall_3a">作品欣赏</li>
            <li class="Waterfall_3a">作品欣赏</li>
            <li class="Waterfall_3a">作品欣赏</li>
            <li class="Waterfall_3a">作品欣赏</li>
            <li class="Waterfall_3a">作品欣赏</li>
            <li class="Waterfall_3a">作品欣赏</li>
        </ul>
        <div class="Waterfall_4">
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            <dl class="piece">
                <img src="images/piece_1.png" />
                <dt>介绍使用3ds Max 2016MCG Creation Graph</dt>
                <dd>2015 年 5 月 6 日</dd>
            </dl>
            
            <ul class="left_b2">
                <li class="left_b2a">首页</li>
                <li class="left_b2a">上一页</li>
                <li class="left_b2b">1</li>
                <li class="left_b2bon">2</li>
                <li class="left_b2b">3</li>
                <li class="left_b2b">4</li>
                <li class="left_b2b">5</li>
                <li class="left_b2b">87</li>
                <li class="left_b2a">下一页</li>
                <li class="left_b2a">尾页</li>
            </ul>
            
        </div>
    </div>
</div>


