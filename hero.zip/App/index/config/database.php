<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require '../App/config/database.php';