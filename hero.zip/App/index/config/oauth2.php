<?php

//xx代表每个provider的唯一标识，也就是文件名的小写
$config['oauth2']['qq'] = array(
    'id' => '101218869',
    'secret' => '22498574e68099c54e491ccf3febc6a9'
);
$config['oauth2']['tweibo'] = array(
    'id' => '801565505',
    'secret' => '529af07977f5292a84536888f4141c91'
);

?>