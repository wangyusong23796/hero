<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'BaseController.php';


class TestController extends BaseController {
	// TODO - Insert your code here
	
	public function index()
	{
		echo 'test';
	}
}
