<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'BaseController.php';

class UserController extends BaseController{
	
	
	public function show()
	{
		echo '用户控制';
	}
	
}