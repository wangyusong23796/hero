<?php namespace App\admin\models;

use Illuminate\Database\Eloquent\Model;

/**
 *
 * Article Model
 *
 */

class AdminUser extends Model
{
	public $timestamps = false;

}
