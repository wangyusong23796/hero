<?php



/**
 *
 * Article Model
 *
 */

class WebType extends Illuminate\Database\Eloquent\Model
{
	public $timestamps = false;

}


?>