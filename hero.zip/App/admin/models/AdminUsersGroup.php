<?php namespace App\admin\models;

use Illuminate\Database\Eloquent\Model;

/**
 *
 * Article Model
 *
*/

class AdminUsersGroup extends Model
{
	public $timestamps = false;
	
}