<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//引入公用数据库文件

require '../App/config/database.php';
