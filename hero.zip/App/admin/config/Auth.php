<?php

$config['users'] = 'admin_users';
$config['groups'] = 'admin_users_groups';
$config['routes'] = 'admin_users_routes';
$config['key'] = 'wangyusongdsadasdsadasd';